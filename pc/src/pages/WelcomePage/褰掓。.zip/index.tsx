import React, { useEffect, useState } from 'react';
import { BuildOutlined, ProjectOutlined } from '@ant-design/icons';
import { primeApi } from '@/services/api';
import type { StatisticVo } from '@/services/apis';
import styles from './index.module.css';

// 数字滚动组件（id 用于区分多个实例，避免重复 id）
const CountUpNumber: React.FC<{ id?: string; end: number; duration?: number }> = ({ id, end, duration = 2000 }) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const domId = id ?? `count-${end}`;

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById(domId);
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, [domId]);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);

      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentCount = Math.floor(easeOutQuart * end);

      setCount(currentCount);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isVisible, end, duration]);

  return (
    <span id={domId} className={styles.countUpNumber}>
      {count.toLocaleString()}
    </span>
  );
};

const WelcomePage: React.FC = () => {
  const [statistic, setStatistic] = useState<StatisticVo | null>(null);

  useEffect(() => {
    const loadStatistic = async () => {
      try {
        const res = await primeApi.getStatistic();
        setStatistic(res);
      } catch (e) {
        console.error('获取统计数据失败:', e);
      }
    };
    loadStatistic();
  }, []);

  return (
    <div className={styles.indexPage}>
      {/* 背景动画元素 */}
      <div className={styles.bgElements}>
        <div className={styles.bgElement}></div>
        <div className={styles.bgElement}></div>
        <div className={styles.bgElement}></div>
        <div className={styles.bgElement}></div>
      </div>

      <div className={styles.container}>
        <header>
          <div className={styles.logo}>
            <div className={styles.logoIcon}>
              <BuildOutlined />
            </div>
            <div className={styles.logoText}>
              <h1>泰州市企业全生命周期管理服务平台</h1>
              <p>Taizhou Enterprise Full Lifecycle Management Service System</p>
            </div>
          </div>
        </header>

        <div className={styles.statsOverview}>
          <div className={styles.statItem}>
            <div className={styles.statValue}>
              <CountUpNumber id="stat-market" end={statistic?.data ?? 0} duration={2500} />
            </div>
            <div className={styles.statLabel}>市场主体</div>
          </div>
          <div className={styles.statItem}>
            <div className={styles.statValue}>
              <CountUpNumber id="stat-sign" end={statistic?.signData ?? 0} duration={2000} />
            </div>
            <div className={styles.statLabel}>已签约项目</div>
          </div>
          <div className={styles.statItem}>
            <div className={styles.statValue}>
              <CountUpNumber id="stat-build" end={statistic?.buildData ?? 0} duration={1500} />
            </div>
            <div className={styles.statLabel}>在建项目</div>
          </div>
        </div>

        <div className={styles.dashboard}>
          <div
            onClick={() => {
              window.location.replace('/home')

            }}
            className={`${styles.departmentCard} ${styles.bgCommerce}`}
            style={{ cursor: 'pointer' }}
          >
            <div className={styles.departmentHeader}>
              <div className={styles.departmentIcon}>
                <BuildOutlined />
              </div>
            </div>
            <h3>企业管理模块</h3>
            <p>全领域归集涉企数据，对企业进行精准画像，实现服务与管理一体化。</p>
            <div className={styles.departmentStages}>
              <div className={styles.stageTag}>数字招商</div>
              <div className={styles.stageTag}>在线审批</div>
              <div className={styles.stageTag}>工程建设</div>
              <div className={styles.stageTag}>竣工达产</div>
              <div className={styles.stageTag}>一企一档</div>
            </div>
          </div>

          <div
            onClick={() =>{
              window.location.replace('/tutorial')
            }}
            className={`${styles.departmentCard} ${styles.bgDevelopment}`}
            style={{ cursor: 'pointer' }}
          >
            <div className={styles.departmentHeader}>
              <div className={styles.departmentIcon}>
                <ProjectOutlined />
              </div>
            </div>
            <h3>项目管理模块</h3>
            <p>聚焦“前期招商”“备案审批”“投资进度”“投产达效”4大环节，采取“一项目一代码”贯穿全流程，实时监控全市项目建设情况</p>
            <div className={styles.departmentStages}>
              <div className={styles.stageTag}>前期招商</div>
              <div className={styles.stageTag}>备案审批</div>
              <div className={styles.stageTag}>开工竣工</div>
              <div className={styles.stageTag}>投产达效</div>
            </div>
          </div>
        </div>

        <div className={styles.footer}>
          <p>泰州市企业全生命周期管理服务平台 | 技术支持：市数据局 市数据产业集团有限公司</p>
        </div>
      </div>
    </div>
  );
};

export default WelcomePage;
